from isLeap import *
from daysSinceYearStart import *
def leapnums(z,x,c,v,b,n):
        leap=0
        while c < n:
            if isLeap(c)==True:
                leap=leap+1
                c=c+1
            else:
                c=c+1
        return leap
def dateDifferences(q,w,e,r,t,y):
    result=(y-e)365+leap+daysSinceYearStart(r,t,y)-daysSinceYearStart(q,w,e)
    return result 
        
        
