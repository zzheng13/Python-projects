def isLeap(a):
    if (a%4==0 and a%100!=0 )==True:
        return True
    if (a%100==0 and a%400!=0)==True:
        return False
    if a%400==0:
        return True
