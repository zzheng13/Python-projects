from daysSinceYearStart import *

def dateDifference(q,w,e,r,t,y):
    result1 = int(daysSinceYearStart(q,e))+w
    result2 = int(daysSinceYearStart(r,y))+t
    num=result1-result2
    num=abs(num)
    return num
