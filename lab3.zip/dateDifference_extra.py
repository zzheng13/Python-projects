from leap import *
from daysSinceYearStart import *
def leapnums(m,x,c,v,b,n):
    leap=0
    while c < n:
        if isLeap(c)==True:
            leap=leap+1
            c=c+1
        else:
            c=c+1
    return leap
def dateDifference(q,w,e,r,t,y):
    if e>y:
        days=(y-e)*365+leapnums(q,w,e,r,t,y)+abs(daysSinceYearStart(q,e)+w-daysSinceYearStart(r,y)-t)
        days=abs(days)
    else:
        days=(y-e)*365+leapnums(q,w,e,r,t,y)+daysSinceYearStart(r,y)+t-daysSinceYearStart(q,e)-w
        days=abs(days)
    return days
        
