def squareRoot(n):
    CurrentGuess = 2
    NextGuess= 1
    while abs(CurrentGuess - NextGuess)>= 0.0001:
        CurrentGuess=NextGuess
        NextGuess = 0.5 * (CurrentGuess + n / CurrentGuess)
    return NextGuess
    
    
