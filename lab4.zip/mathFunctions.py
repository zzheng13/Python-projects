def log(n):
    new = n//2
    if new <= 1:
        return new
    else:
        loop = 1
        while new > 1:
            loop=loop+1
            new = new //2
        return loop

def squareRoot(n):
    CurrentGuess = 2
    NextGuess= 1
    while abs(CurrentGuess - NextGuess)>= 0.0001:
        CurrentGuess=NextGuess
        NextGuess = 0.5 * (CurrentGuess + n / CurrentGuess)
    return NextGuess
    
def triangleArea(a,b,c):
    p=(a+b+c)/2
    d=p*(p-a)*(p-b)*(p-c)
    A=squareRoot(d)
    return A
    
