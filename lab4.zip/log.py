def log(n):
    new = n//2
    if new <= 1:
        return new
    else:
        loop = 1
        while new > 1:
            loop=loop+1
            new = new //2
        return loop
